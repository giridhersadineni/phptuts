<?php
$servername="localhost";
$dbuser="accapp";
$dbpwd="giridher";

?>